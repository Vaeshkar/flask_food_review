from .auth import auth_bp # Importing the authentification blueprint from auth.py file
from .restaurants import restaurants_bp # Importing the restaurants blueprint from restaurants file